#include "graphics/guest_gpu/gpu_format.h"
#include "graphics/shader/recompiler/ir/BindlessBindings.h"
#include "graphics/shader/recompiler/backend/spirv/SpirvEmitter.h"
#include "graphics/shader/recompiler/backend/spirv/spirvEmitterInstructions.h"
#include "graphics/shader/recompiler/frontend/decode/ImageOps.h"

#include <algorithm>
#include <atomic>
#include <bit>
#include <cstdio>
#include <optional>

namespace Libs::Graphics::ShaderRecompiler::Spirv::Emitter {
namespace {

uint32_t DmaskComponentIndex(uint32_t dmask, uint32_t component) {
	uint32_t index = 0;
	for (uint32_t i = 0; i < component; i++) {
		index += (dmask >> i) & 1u;
	}
	return index;
}

uint32_t DmaskComponent(uint32_t dmask, uint32_t index) {
	for (uint32_t component = 0; component < 4u; component++) {
		if (((dmask >> component) & 1u) != 0u && index-- == 0u) return component;
	}
	return 0u;
}

uint32_t ImageGatherComponent(uint32_t dmask) {
	switch (dmask) {
		case 0x2u: return 1;
		case 0x4u: return 2;
		case 0x8u: return 3;
		default: return 0;
	}
}

bool HasFlag(const IR::MemoryInfo& mem, uint32_t flag) {
	return (mem.image_sample_flags & flag) != 0u;
}

uint32_t AddressU32(ValueEmitContext& ctx, const IR::MemoryInfo& mem, const IR::Inst& address,
                    uint32_t component) {
	const auto layout = Decoder::ImageAddressComponentLayout(mem.image_sample_flags, component);
	const auto packed = layout.bit_offset / 32u;
	if (packed >= address.NumArgs()) return ConstantU32(ctx.state, 0);
	auto value = ctx.Def(address.Arg(packed));
	if (layout.bit_width == 16u) {
		if ((layout.bit_offset & 31u) != 0u) {
			value = Binary(ctx.state, spv::OpShiftRightLogical, TypeU32(ctx.state), value,
			               ConstantU32(ctx.state, 16));
		}
		value = Binary(ctx.state, spv::OpBitwiseAnd, TypeU32(ctx.state), value,
		               ConstantU32(ctx.state, 0xffffu));
	}
	return value;
}

uint32_t AddressF32(ValueEmitContext& ctx, const IR::MemoryInfo& mem, const IR::Inst& address,
                    uint32_t component) {
	const auto value = AddressU32(ctx, mem, address, component);
	return Decoder::ImageAddressComponentLayout(mem.image_sample_flags, component).bit_width == 16u
	           ? EmitF16BitsToF32(ctx.state, value)
	           : Unary(ctx.state, spv::OpBitcast, TypeF32(ctx.state), value);
}

ImageSampleLayout Layout(const IR::MemoryInfo& mem) {
	ImageSampleLayout layout;
	uint32_t          cursor = 0;
	const auto&       info   = ImageDimensionInfoFor(mem.image_dimension);
	if (HasFlag(mem, Decoder::ImageSampleFlagOffset)) layout.offset = cursor++;
	if (HasFlag(mem, Decoder::ImageSampleFlagBias)) layout.bias = cursor++;
	if (HasFlag(mem, Decoder::ImageSampleFlagCompare)) layout.dref = cursor++;
	if (HasFlag(mem, Decoder::ImageSampleFlagDerivative)) {
		layout.grad_x = cursor;
		cursor += info.spatial_components;
		layout.grad_y = cursor;
		cursor += info.spatial_components;
	}
	layout.coord = cursor;
	cursor += info.coordinate_components;
	if (HasFlag(mem, Decoder::ImageSampleFlagLod)) layout.lod = cursor++;
	if (HasFlag(mem, Decoder::ImageSampleFlagLodClamp)) layout.clamp = cursor++;
	return layout;
}

uint32_t ZeroF32(EmitterState& state) {
	return ConstantF32(state, 0);
}

uint32_t CubeAxis(EmitterState& state, uint32_t value) {
	return Binary(state, spv::OpFSub, TypeF32(state), value, ConstantF32(state, 0x3f800000u));
}

uint32_t CubeLayer(EmitterState& state, uint32_t value) {
	const auto guest = state.builder.AllocateId();
	state.builder.AddFunction(spv::OpConvertFToU, TypeU32(state), guest, value);
	const auto padding = Binary(
	    state, spv::OpShiftLeftLogical, TypeU32(state),
	    Binary(state, spv::OpShiftRightLogical, TypeU32(state), guest, ConstantU32(state, 3)),
	    ConstantU32(state, 1));
	const auto host   = Binary(state, spv::OpISub, TypeU32(state), guest, padding);
	const auto result = state.builder.AllocateId();
	state.builder.AddFunction(spv::OpConvertUToF, TypeF32(state), result, host);
	return result;
}

uint32_t CoordF32(ValueEmitContext& ctx, const IR::MemoryInfo& mem, const IR::Inst& address,
                  uint32_t first, uint32_t components, bool cube = false) {
	auto x = AddressF32(ctx, mem, address, first);
	if (components == 1u) return x;
	auto y = mem.image_address_components > first + 1u ? AddressF32(ctx, mem, address, first + 1u)
	                                                   : ZeroF32(ctx.state);
	if (cube) {
		x = CubeAxis(ctx.state, x);
		y = CubeAxis(ctx.state, y);
	}
	const auto result = ctx.state.builder.AllocateId();
	if (components == 3u) {
		auto z = mem.image_address_components > first + 2u
		             ? AddressF32(ctx, mem, address, first + 2u)
		             : ZeroF32(ctx.state);
		if (cube) z = CubeLayer(ctx.state, z);
		ctx.state.builder.AddFunction(spv::OpCompositeConstruct, TypeF32Vector(ctx.state, 3),
		                              result, x, y, z);
	} else {
		ctx.state.builder.AddFunction(spv::OpCompositeConstruct, TypeF32Vector(ctx.state, 2),
		                              result, x, y);
	}
	return result;
}

uint32_t CoordU32(ValueEmitContext& ctx, const IR::MemoryInfo& mem, const IR::Inst& address,
                  ImageDimension dimension) {
	const auto components = ImageDimensionInfoFor(dimension).coordinate_components;
	const auto x          = AddressU32(ctx, mem, address, 0);
	if (components == 1u) return x;
	const auto y      = mem.image_address_components > 1u ? AddressU32(ctx, mem, address, 1)
	                                                      : ConstantU32(ctx.state, 0);
	const auto result = ctx.state.builder.AllocateId();
	if (components == 3u) {
		const auto z = mem.image_address_components > 2u ? AddressU32(ctx, mem, address, 2)
		                                                 : ConstantU32(ctx.state, 0);
		ctx.state.builder.AddFunction(spv::OpCompositeConstruct, TypeU32Vector(ctx.state, 3),
		                              result, x, y, z);
	} else {
		ctx.state.builder.AddFunction(spv::OpCompositeConstruct, TypeU32Vector(ctx.state, 2),
		                              result, x, y);
	}
	return result;
}

uint32_t LodU32(ValueEmitContext& ctx, const IR::MemoryInfo& mem, const IR::Inst& address,
                ImageDimension dimension) {
	const auto component = ImageDimensionInfoFor(dimension).coordinate_components;
	return mem.image_has_mip && mem.image_address_components > component
	           ? AddressU32(ctx, mem, address, component)
	           : ConstantU32(ctx.state, 0);
}

uint32_t FloatBits(ValueEmitContext& ctx, uint32_t value) {
	return Unary(ctx.state, spv::OpBitcast, TypeU32(ctx.state), value);
}

uint32_t SampledComponentBits(ValueEmitContext& ctx, uint32_t value,
                              Prospero::TextureNumericClass numeric_class) {
	if (numeric_class == Prospero::TextureNumericClass::Uint) {
		return value;
	}
	return Unary(ctx.state, spv::OpBitcast, TypeU32(ctx.state), value);
}

uint32_t SampledComponentZero(EmitterState& state, Prospero::TextureNumericClass numeric_class) {
	switch (numeric_class) {
		case Prospero::TextureNumericClass::Float: return ZeroF32(state);
		case Prospero::TextureNumericClass::Uint: return ConstantU32(state, 0);
		case Prospero::TextureNumericClass::Sint: return ConstantI32(state, 0);
		case Prospero::TextureNumericClass::Unsupported: break;
	}
	EXIT("invalid sampled image numeric class");
}

uint32_t ResultVector(ValueEmitContext& ctx, uint32_t value,
                      Prospero::TextureNumericClass numeric_class, bool dref,
                      const IR::MemoryInfo& mem, bool gather = false) {
	auto value_class = numeric_class;
	if (dref) {
		value_class = Prospero::TextureNumericClass::Float;
	}
	const bool integer = value_class == Prospero::TextureNumericClass::Uint ||
	                     value_class == Prospero::TextureNumericClass::Sint;
	if (mem.data_bits == 16u) {
		uint32_t   packed[4] = {ConstantU32(ctx.state, 0), ConstantU32(ctx.state, 0),
		                        ConstantU32(ctx.state, 0), ConstantU32(ctx.state, 0)};
		const auto scalar    = [&](uint32_t index) {
			if (dref) return value;
			const auto component = gather ? index : DmaskComponent(mem.dmask, index);
			const auto result    = ctx.state.builder.AllocateId();
			ctx.state.builder.AddFunction(spv::OpCompositeExtract,
			                              ImageScalarType(ctx.state, value_class), result, value,
			                              component);
			return result;
		};
		for (uint32_t word = 0; word < mem.data_dwords; word++) {
			const auto low_index  = word * 2u;
			const auto high_index = low_index + 1u;
			const auto low        = scalar(low_index);
			const auto high       = high_index < mem.component_count
			                            ? scalar(high_index)
			                            : SampledComponentZero(ctx.state, value_class);
			if (integer) {
				const auto low_bits  = SampledComponentBits(ctx, low, value_class);
				const auto high_bits = SampledComponentBits(ctx, high, value_class);
				const auto mask      = ConstantU32(ctx.state, 0xffffu);
				packed[word] =
				    Binary(ctx.state, spv::OpBitwiseOr, TypeU32(ctx.state),
				           Binary(ctx.state, spv::OpBitwiseAnd, TypeU32(ctx.state), low_bits, mask),
				           Binary(ctx.state, spv::OpShiftLeftLogical, TypeU32(ctx.state),
				                  Binary(ctx.state, spv::OpBitwiseAnd, TypeU32(ctx.state),
				                         high_bits, mask),
				                  ConstantU32(ctx.state, 16u)));
			} else {
				const auto pair = ctx.state.builder.AllocateId();
				ctx.state.builder.AddFunction(spv::OpCompositeConstruct,
				                              TypeF32Vector(ctx.state, 2), pair, low, high);
				packed[word] = ctx.state.builder.AllocateId();
				ctx.state.builder.AddFunction(spv::OpExtInst, TypeU32(ctx.state), packed[word],
				                              GlslStd450(ctx.state), GLSLstd450PackHalf2x16, pair);
			}
		}
		const auto result = ctx.state.builder.AllocateId();
		ctx.state.builder.AddFunction(spv::OpCompositeConstruct, TypeU32Vector(ctx.state, 4),
		                              result, packed[0], packed[1], packed[2], packed[3]);
		return result;
	}
	uint32_t component[4] {};
	for (uint32_t index = 0; index < 4u; index++) {
		if (dref) {
			component[index] = index == 0u ? FloatBits(ctx, value) : ConstantU32(ctx.state, 0);
			continue;
		}
		const auto scalar = ctx.state.builder.AllocateId();
		ctx.state.builder.AddFunction(
		    spv::OpCompositeExtract, ImageScalarType(ctx.state, value_class), scalar, value, index);
		component[index] = SampledComponentBits(ctx, scalar, value_class);
	}
	const auto result = ctx.state.builder.AllocateId();
	ctx.state.builder.AddFunction(spv::OpCompositeConstruct, TypeU32Vector(ctx.state, 4), result,
	                              component[0], component[1], component[2], component[3]);
	return result;
}

uint32_t QueryDimensions(ValueEmitContext& ctx, const IR::MemoryInfo& mem,
                         const IR::Inst& address) {
	const auto  dimension = ctx.state.program.info.images.at(mem.resource).dimension;
	const auto& info      = ImageDimensionInfoFor(dimension);
	const auto  image     = LoadSampledImageDescriptor(ctx.state, mem.resource);
	const auto  size      = ctx.state.builder.AllocateId();
	if (info.multisampled != 0u) {
		ctx.state.builder.AddFunction(spv::OpImageQuerySize,
		                              ImageViewSizeType(ctx.state, dimension), size, image);
	} else {
		ctx.state.builder.AddFunction(spv::OpImageQuerySizeLod,
		                              ImageViewSizeType(ctx.state, dimension), size, image,
		                              AddressU32(ctx, mem, address, 0));
	}
	const auto components = info.coordinate_components;
	uint32_t   result[4]  = {ConstantU32(ctx.state, 0), ConstantU32(ctx.state, 0),
	                         ConstantU32(ctx.state, 0), ConstantU32(ctx.state, 0)};
	if (components == 1u) {
		result[0] = size;
	} else {
		for (uint32_t index = 0; index < components; index++) {
			result[index] = ctx.state.builder.AllocateId();
			ctx.state.builder.AddFunction(spv::OpCompositeExtract, TypeU32(ctx.state),
			                              result[index], size, index);
		}
	}
	if (info.multisampled == 0u) {
		result[3] = ctx.state.builder.AllocateId();
		ctx.state.builder.AddFunction(spv::OpImageQueryLevels, TypeU32(ctx.state), result[3],
		                              image);
	}
	const auto vector = ctx.state.builder.AllocateId();
	ctx.state.builder.AddFunction(spv::OpCompositeConstruct, TypeU32Vector(ctx.state, 4), vector,
	                              result[0], result[1], result[2], result[3]);
	return vector;
}

uint32_t PackedOffset(ValueEmitContext& ctx, const IR::MemoryInfo& mem, const IR::Inst& address,
                      const ImageSampleLayout& layout, ImageDimension dimension) {
	const auto components = ImageDimensionInfoFor(dimension).spatial_components;
	const auto zero       = ConstantI32(ctx.state, 0);
	if (layout.offset == NoImageComponent || mem.image_address_components <= layout.offset) {
		if (components == 1u) return zero;
		const auto result = ctx.state.builder.AllocateId();
		if (components == 3u) {
			ctx.state.builder.AddFunction(spv::OpCompositeConstruct, TypeI32Vector(ctx.state, 3),
			                              result, zero, zero, zero);
		} else {
			ctx.state.builder.AddFunction(spv::OpCompositeConstruct, TypeI32Vector(ctx.state, 2),
			                              result, zero, zero);
		}
		return result;
	}
	const auto packed    = Unary(ctx.state, spv::OpBitcast, TypeI32(ctx.state),
	                             AddressU32(ctx, mem, address, layout.offset));
	uint32_t   values[3] = {zero, zero, zero};
	for (uint32_t index = 0; index < components; index++) {
		values[index] = ctx.state.builder.AllocateId();
		ctx.state.builder.AddFunction(spv::OpBitFieldSExtract, TypeI32(ctx.state), values[index],
		                              packed, ConstantU32(ctx.state, index * 8u),
		                              ConstantU32(ctx.state, 6));
	}
	if (components == 1u) return values[0];
	const auto result = ctx.state.builder.AllocateId();
	if (components == 3u) {
		ctx.state.builder.AddFunction(spv::OpCompositeConstruct, TypeI32Vector(ctx.state, 3),
		                              result, values[0], values[1], values[2]);
	} else {
		ctx.state.builder.AddFunction(spv::OpCompositeConstruct, TypeI32Vector(ctx.state, 2),
		                              result, values[0], values[1]);
	}
	return result;
}

// IMAGE_SAMPLE*_O (RDNA 2 ISA 8.2.5): one dword of six-bit signed texel offsets, x in bits 5:0,
// y in 13:8 and z in 21:16, added to the texel coordinates of the level that is read. Vulkan
// accepts only constant offsets on sample instructions (ConstOffset), within
// [minTexelOffset, maxTexelOffset]; every implementation supports -8..7. Other offsets move the
// normalized coordinate by offset / level size instead (ApplyDynamicSampleOffset).
struct SampleOffset {
	uint32_t const_offset = 0;     // ConstOffset operand id; 0 when there is none
	uint32_t packed       = 0;     // the packed offsets when they need ApplyDynamicSampleOffset
	bool     dynamic      = false;
};

int32_t SignExtend6(uint32_t value) {
	return static_cast<int32_t>((value & 0x3fu) ^ 0x20u) - 0x20;
}

// The condition masking every use of an image result: each use is a component extract whose
// every use is SelectU32(condition, component, old), i.e. the destination write under EXEC.
// Lanes where it is false discard the result, so an operand written under the same condition
// (Select(condition, value, old)) may be read as `value`.
std::optional<IR::Value> ResultExecGuard(const IR::Inst& inst) {
	std::optional<IR::Value> guard;
	if (!inst.HasUses()) {
		return std::nullopt;
	}
	for (const auto& use: inst.Uses()) {
		const auto* extract = use.user;
		if (extract == nullptr || extract->GetOpcode() != IR::ValueOpcode::CompositeExtractU32x4 ||
		    !extract->HasUses()) {
			return std::nullopt;
		}
		for (const auto& extract_use: extract->Uses()) {
			const auto* select = extract_use.user;
			if (select == nullptr || select->GetOpcode() != IR::ValueOpcode::SelectU32 ||
			    extract_use.operand != 1u) {
				return std::nullopt;
			}
			const auto condition = select->Arg(0).Resolve();
			if (guard.has_value() && !(*guard == condition)) {
				return std::nullopt;
			}
			guard = condition;
		}
	}
	return guard;
}

SampleOffset SampleOffsetFor(ValueEmitContext& ctx, const IR::Inst& inst, const IR::MemoryInfo& mem,
                             const IR::Inst& address, const ImageSampleLayout& layout,
                             ImageDimension dimension, bool cube, bool bindless) {
	SampleOffset result;
	if (layout.offset == NoImageComponent || mem.image_address_components <= layout.offset) {
		return result;
	}
	if (cube) {
		static std::atomic_flag warned = ATOMIC_FLAG_INIT;
		if (!warned.test_and_set(std::memory_order_relaxed)) {
			std::fputs("Warning: IMAGE_SAMPLE*_O offsets on a cube map are ignored.\n", stderr);
		}
		return result;
	}
	auto&      state      = ctx.state;
	const auto components = ImageDimensionInfoFor(dimension).spatial_components;
	const auto packed_index =
	    Decoder::ImageAddressComponentLayout(mem.image_sample_flags, layout.offset).bit_offset / 32u;
	auto value =
	    packed_index < address.NumArgs() ? address.Arg(packed_index).Resolve() : IR::Value(0u);
	// Offsets are literals in guest code; under a non-uniform EXEC the register holds
	// Select(exec, literal, old), which the lanes that keep the result see as the literal.
	if (!value.IsImmediate()) {
		if (const auto guard = ResultExecGuard(inst); guard.has_value()) {
			while (!value.IsImmediate()) {
				const auto* select = value.TryInstruction();
				if (select == nullptr || select->GetOpcode() != IR::ValueOpcode::SelectU32 ||
				    !(select->Arg(0).Resolve() == *guard)) {
					break;
				}
				value = select->Arg(1).Resolve();
			}
		}
	}
	if (value.IsImmediate() &&
	    (value.GetType() == IR::Type::U32 || value.GetType() == IR::Type::F32)) {
		const auto bits = value.GetType() == IR::Type::U32 ? value.U32()
		                                                   : std::bit_cast<uint32_t>(value.F32Value());
		int32_t offsets[3] = {};
		bool    in_range   = true;
		bool    any        = false;
		for (uint32_t index = 0; index < components; index++) {
			offsets[index] = SignExtend6(bits >> (index * 8u));
			in_range       = in_range && offsets[index] >= -8 && offsets[index] <= 7;
			any            = any || offsets[index] != 0;
		}
		if (!any) {
			return result;
		}
		if (in_range) {
			uint32_t ids[3] = {};
			for (uint32_t index = 0; index < components; index++) {
				ids[index] = ConstantI32(state, offsets[index]);
			}
			if (components == 1u) {
				result.const_offset = ids[0];
			} else if (components == 2u) {
				result.const_offset = state.builder.Constant(
				    spv::OpConstantComposite, TypeI32Vector(state, 2), ids[0], ids[1]);
			} else {
				result.const_offset = state.builder.Constant(
				    spv::OpConstantComposite, TypeI32Vector(state, 3), ids[0], ids[1], ids[2]);
			}
			return result;
		}
	}
	if (bindless) {
		// The dynamic path queries the image's size through its descriptor, which a bindless
		// image does not have in this form.
		static std::atomic_flag warned = ATOMIC_FLAG_INIT;
		if (!warned.test_and_set(std::memory_order_relaxed)) {
			std::fputs("Warning: non-constant IMAGE_SAMPLE*_O offsets on a bindless image are "
			           "ignored.\n",
			           stderr);
		}
		return result;
	}
	result.dynamic = true;
	result.packed  = AddressU32(ctx, mem, address, layout.offset);
	return result;
}

// Moves `coord` by the packed texel offsets divided by the size of the level `level_f32`
// (relative to the view's base, clamped to the view's levels). Exact for single-level reads up
// to float rounding; with linear mip filtering the coarser level moves by half the offset.
uint32_t ApplyDynamicSampleOffset(EmitterState& state, uint32_t resource, uint32_t coord,
                                  ImageDimension dimension, uint32_t packed, uint32_t level_f32) {
	static std::atomic_flag warned = ATOMIC_FLAG_INIT;
	if (!warned.test_and_set(std::memory_order_relaxed)) {
		std::fputs("Warning: IMAGE_SAMPLE*_O offsets that are not constant or lie outside -8..7 "
		           "move the coordinate by offset / level size.\n",
		           stderr);
	}
	state.builder.RequireCapability(spv::CapabilityImageQuery);
	const auto& info       = ImageDimensionInfoFor(dimension);
	const auto  components = info.spatial_components;
	const auto  image      = LoadSampledImageDescriptor(state, resource);
	const auto  levels     = state.builder.AllocateId();
	state.builder.AddFunction(spv::OpImageQueryLevels, TypeU32(state), levels, image);
	const auto floored = state.builder.AllocateId();
	state.builder.AddFunction(spv::OpExtInst, TypeF32(state), floored, GlslStd450(state),
	                          GLSLstd450FMax, level_f32, ConstantF32Value(state, 0.0f));
	const auto level_float = state.builder.AllocateId();
	state.builder.AddFunction(spv::OpExtInst, TypeF32(state), level_float, GlslStd450(state),
	                          GLSLstd450Floor, floored);
	const auto level_u32 = state.builder.AllocateId();
	state.builder.AddFunction(spv::OpConvertFToU, TypeU32(state), level_u32, level_float);
	const auto last  = Binary(state, spv::OpISub, TypeU32(state), levels, ConstantU32(state, 1));
	const auto level = state.builder.AllocateId();
	state.builder.AddFunction(spv::OpExtInst, TypeU32(state), level, GlslStd450(state),
	                          GLSLstd450UMin, level_u32, last);
	const auto size = state.builder.AllocateId();
	state.builder.AddFunction(spv::OpImageQuerySizeLod, ImageViewSizeType(state, dimension), size,
	                          image, level);
	const auto packed_i32 = Unary(state, spv::OpBitcast, TypeI32(state), packed);
	uint32_t   moved[4]   = {};
	for (uint32_t index = 0; index < info.coordinate_components; index++) {
		auto component = coord;
		if (info.coordinate_components > 1u) {
			component = state.builder.AllocateId();
			state.builder.AddFunction(spv::OpCompositeExtract, TypeF32(state), component, coord,
			                          index);
		}
		if (index < components) {
			const auto offset = state.builder.AllocateId();
			state.builder.AddFunction(spv::OpBitFieldSExtract, TypeI32(state), offset, packed_i32,
			                          ConstantU32(state, index * 8u), ConstantU32(state, 6));
			const auto offset_f32 = state.builder.AllocateId();
			state.builder.AddFunction(spv::OpConvertSToF, TypeF32(state), offset_f32, offset);
			auto extent = size;
			if (info.coordinate_components > 1u) {
				extent = state.builder.AllocateId();
				state.builder.AddFunction(spv::OpCompositeExtract, TypeU32(state), extent, size,
				                          index);
			}
			const auto extent_f32 = state.builder.AllocateId();
			state.builder.AddFunction(spv::OpConvertUToF, TypeF32(state), extent_f32, extent);
			component = Binary(state, spv::OpFAdd, TypeF32(state), component,
			                   Binary(state, spv::OpFDiv, TypeF32(state), offset_f32, extent_f32));
		}
		moved[index] = component;
	}
	if (info.coordinate_components == 1u) {
		return moved[0];
	}
	const auto result = state.builder.AllocateId();
	if (info.coordinate_components == 2u) {
		state.builder.AddFunction(spv::OpCompositeConstruct, TypeF32Vector(state, 2), result,
		                          moved[0], moved[1]);
	} else {
		state.builder.AddFunction(spv::OpCompositeConstruct, TypeF32Vector(state, 3), result,
		                          moved[0], moved[1], moved[2]);
	}
	return result;
}

uint32_t HorizontalOffsets(EmitterState& state, ImageDimension dimension) {
	const auto components   = ImageDimensionInfoFor(dimension).spatial_components;
	const auto count        = ConstantU32(state, 4);
	const auto element_type = components == 1u ? TypeI32(state) : TypeI32Vector(state, 2);
	const auto array_type   = state.builder.Type(spv::OpTypeArray, element_type, count);
	uint32_t   offsets[4] {};
	for (uint32_t index = 0; index < 4u; index++) {
		const auto x = ConstantI32(state, static_cast<int32_t>(index) - 1);
		if (components == 1u) {
			offsets[index] = x;
		} else {
			offsets[index] = state.builder.Constant(
			    spv::OpConstantComposite, TypeI32Vector(state, 2), x, ConstantI32(state, 0));
		}
	}
	return state.builder.Constant(spv::OpConstantComposite, array_type, offsets[0], offsets[1],
	                              offsets[2], offsets[3]);
}

uint32_t InverseSwizzle(uint32_t swizzle, uint32_t component) {
	for (uint32_t source = 0; source < 4u; source++) {
		if (((swizzle >> (source * 3u)) & 7u) == 4u + component) return source;
	}
	return UINT32_MAX;
}

Format::BufferFormatInfo ImageConversionFormat(const EmitterState&   state,
                                               const IR::MemoryInfo& mem) {
	const auto format = state.program.info.images[mem.resource].conversion_format;
	if (format == Prospero::BufferFormat::kInvalid) return {};
	const auto info = Format::GetFormatInfo(format);
	EXIT_IF(Prospero::SampledTextureNumericClass(format) != Prospero::TextureNumericClass::Uint ||
	        Prospero::RemapTextureFormat(format) == format ||
	        info.type != Format::ComponentType::Uint || !info.packed_bitfield ||
	        info.byte_size != sizeof(uint32_t) || info.component_count == 0u ||
	        info.component_count > 4u);
	return info;
}

uint32_t UnpackImageTexel(ValueEmitContext& ctx, const IR::MemoryInfo& mem, uint32_t texel) {
	const auto info = ImageConversionFormat(ctx.state, mem);
	if (info.format == Prospero::BufferFormat::kInvalid) return texel;

	const auto packed = ctx.state.builder.AllocateId();
	ctx.state.builder.AddFunction(spv::OpCompositeExtract, TypeU32(ctx.state), packed, texel, 0u);
	uint32_t components[4] = {ConstantU32(ctx.state, 0), ConstantU32(ctx.state, 0),
	                          ConstantU32(ctx.state, 0), ConstantU32(ctx.state, 0)};
	for (uint32_t component = 0; component < info.component_count; component++) {
		components[component] = ctx.state.builder.AllocateId();
		ctx.state.builder.AddFunction(spv::OpBitFieldUExtract, TypeU32(ctx.state),
		                              components[component], packed,
		                              ConstantU32(ctx.state, info.component_bit_offset[component]),
		                              ConstantU32(ctx.state, info.component_bits[component]));
	}
	for (uint32_t component = info.component_count; component < 4u; component++) {
		components[component] = components[component % info.component_count];
	}

	const auto swizzle = ctx.state.program.info.images[mem.resource].shader_swizzle;
	uint32_t   selected[4] {};
	for (uint32_t component = 0; component < 4u; component++) {
		const auto selector = (swizzle >> (component * 3u)) & 7u;
		if (selector == 1u) {
			selected[component] = ConstantU32(ctx.state, 1u);
		} else if (selector >= 4u) {
			selected[component] = components[selector - 4u];
		} else {
			selected[component] = ConstantU32(ctx.state, 0u);
		}
	}
	const auto result = ctx.state.builder.AllocateId();
	ctx.state.builder.AddFunction(spv::OpCompositeConstruct, TypeU32Vector(ctx.state, 4), result,
	                              selected[0], selected[1], selected[2], selected[3]);
	return result;
}

uint32_t UnpackImageGather(ValueEmitContext& ctx, const IR::MemoryInfo& mem, uint32_t gathered) {
	const auto info = ImageConversionFormat(ctx.state, mem);
	if (info.format == Prospero::BufferFormat::kInvalid) return gathered;

	const auto component = ImageGatherComponent(mem.dmask);
	const auto selector =
	    (ctx.state.program.info.images[mem.resource].shader_swizzle >> (component * 3u)) & 7u;
	if (selector < 4u) {
		const auto value = ConstantU32(ctx.state, selector == 1u ? 1u : 0u);
		return ctx.state.builder.Constant(spv::OpConstantComposite, TypeU32Vector(ctx.state, 4),
		                                  value, value, value, value);
	}

	uint32_t values[4] {};
	for (uint32_t lane = 0; lane < 4u; lane++) {
		const auto packed = ctx.state.builder.AllocateId();
		ctx.state.builder.AddFunction(spv::OpCompositeExtract, TypeU32(ctx.state), packed, gathered,
		                              lane);
		values[lane]        = ctx.state.builder.AllocateId();
		const auto physical = (selector - 4u) % info.component_count;
		ctx.state.builder.AddFunction(spv::OpBitFieldUExtract, TypeU32(ctx.state), values[lane],
		                              packed,
		                              ConstantU32(ctx.state, info.component_bit_offset[physical]),
		                              ConstantU32(ctx.state, info.component_bits[physical]));
	}
	const auto result = ctx.state.builder.AllocateId();
	ctx.state.builder.AddFunction(spv::OpCompositeConstruct, TypeU32Vector(ctx.state, 4), result,
	                              values[0], values[1], values[2], values[3]);
	return result;
}

uint32_t EmitOneDimensionalGatherLz(ValueEmitContext& ctx, const IR::MemoryInfo& mem,
                                    uint32_t coord, Prospero::TextureNumericClass numeric_class) {
	auto& state = ctx.state;
	state.builder.RequireCapability(spv::CapabilityImageQuery);
	const auto image = LoadSampledImageDescriptor(state, mem.resource);
	const auto width = state.builder.AllocateId();
	state.builder.AddFunction(spv::OpImageQuerySizeLod, TypeU32(state), width, image,
	                          ConstantU32(state, 0));
	const auto width_f32 = state.builder.AllocateId();
	state.builder.AddFunction(spv::OpConvertUToF, TypeF32(state), width_f32, width);
	const auto left = state.builder.AllocateId();
	state.builder.AddFunction(spv::OpExtInst, TypeF32(state), left, GlslStd450(state),
	                          GLSLstd450Floor,
	                          Binary(state, spv::OpFSub, TypeF32(state),
	                                 Binary(state, spv::OpFMul, TypeF32(state), coord, width_f32),
	                                 ConstantF32(state, 0x3f000000u)));

	const auto sampled     = MakeSampledImage(state, mem.resource, mem.sampler);
	const auto vector_type = ImageVectorType(state, numeric_class, 4);
	const auto scalar_type = ImageScalarType(state, numeric_class);
	const auto component =
	    ImageConversionFormat(state, mem).format == Prospero::BufferFormat::kInvalid
	        ? ImageGatherComponent(mem.dmask)
	        : 0u;
	uint32_t values[2] {};
	for (uint32_t index = 0; index < 2u; index++) {
		const auto sample_coord =
		    Binary(state, spv::OpFDiv, TypeF32(state),
		           Binary(state, spv::OpFAdd, TypeF32(state), left,
		                  ConstantF32(state, index == 0u ? 0x3f000000u : 0x3fc00000u)),
		           width_f32);
		const auto texel = state.builder.AllocateId();
		state.builder.AddFunction(spv::OpImageSampleExplicitLod, vector_type, texel, sampled,
		                          sample_coord, spv::ImageOperandsLodMask, ZeroF32(state));
		values[index] = state.builder.AllocateId();
		state.builder.AddFunction(spv::OpCompositeExtract, scalar_type, values[index], texel,
		                          component);
	}
	const auto result = state.builder.AllocateId();
	state.builder.AddFunction(spv::OpCompositeConstruct, vector_type, result, values[0], values[1],
	                          values[1], values[0]);
	return result;
}

uint32_t PackImageTexel(ValueEmitContext& ctx, const IR::MemoryInfo& mem, uint32_t texel) {
	const auto info = ImageConversionFormat(ctx.state, mem);
	if (info.format == Prospero::BufferFormat::kInvalid) return texel;

	auto packed = ConstantU32(ctx.state, 0u);
	for (uint32_t component = 0; component < info.component_count; component++) {
		const auto value = ctx.state.builder.AllocateId();
		ctx.state.builder.AddFunction(spv::OpCompositeExtract, TypeU32(ctx.state), value, texel,
		                              component);
		const auto maximum =
		    ConstantU32(ctx.state, info.component_bits[component] == 32u
		                               ? UINT32_MAX
		                               : (1u << info.component_bits[component]) - 1u);
		const auto within =
		    Binary(ctx.state, spv::OpULessThan, TypeBool(ctx.state), value, maximum);
		const auto clamped = ctx.state.builder.AllocateId();
		ctx.state.builder.AddFunction(spv::OpSelect, TypeU32(ctx.state), clamped, within, value,
		                              maximum);
		const auto shifted =
		    info.component_bit_offset[component] == 0u
		        ? clamped
		        : Binary(ctx.state, spv::OpShiftLeftLogical, TypeU32(ctx.state), clamped,
		                 ConstantU32(ctx.state, info.component_bit_offset[component]));
		packed = Binary(ctx.state, spv::OpBitwiseOr, TypeU32(ctx.state), packed, shifted);
	}
	const auto zero   = ConstantU32(ctx.state, 0u);
	const auto result = ctx.state.builder.AllocateId();
	ctx.state.builder.AddFunction(spv::OpCompositeConstruct, TypeU32Vector(ctx.state, 4), result,
	                              packed, zero, zero, zero);
	return result;
}

uint32_t StoreTexel(ValueEmitContext& ctx, const IR::MemoryInfo& mem, uint32_t data, bool integer) {
	const auto swizzle = ctx.state.program.info.images[mem.resource].shader_swizzle;
	uint32_t   values[4] {};
	const auto dmask = mem.dmask != 0u ? mem.dmask : 1u;
	for (uint32_t component = 0; component < 4u; component++) {
		const auto source = InverseSwizzle(swizzle, component);
		uint32_t   raw    = ConstantU32(ctx.state, 0);
		if (source < 4u && ((dmask >> source) & 1u) != 0u) {
			const auto packed_index = DmaskComponentIndex(dmask, source);
			raw                     = ctx.state.builder.AllocateId();
			ctx.state.builder.AddFunction(spv::OpCompositeExtract, TypeU32(ctx.state), raw, data,
			                              mem.data_bits == 16u ? packed_index / 2u : packed_index);
			if (mem.data_bits == 16u) {
				if ((packed_index & 1u) != 0u) {
					raw = Binary(ctx.state, spv::OpShiftRightLogical, TypeU32(ctx.state), raw,
					             ConstantU32(ctx.state, 16u));
				}
				raw = Binary(ctx.state, spv::OpBitwiseAnd, TypeU32(ctx.state), raw,
				             ConstantU32(ctx.state, 0xffffu));
			}
		}
		values[component] = integer ? raw
		                    : mem.data_bits == 16u
		                        ? EmitF16BitsToF32(ctx.state, raw)
		                        : Unary(ctx.state, spv::OpBitcast, TypeF32(ctx.state), raw);
	}
	const auto texel = ctx.state.builder.AllocateId();
	ctx.state.builder.AddFunction(spv::OpCompositeConstruct,
	                              integer ? TypeU32Vector(ctx.state, 4)
	                                      : TypeF32Vector(ctx.state, 4),
	                              texel, values[0], values[1], values[2], values[3]);
	return PackImageTexel(ctx, mem, texel);
}

} // namespace

// The bindless slot of the image handle's key: translation[region + key] when the key is inside
// the heap's entry count (both from the flattened SRT, patched by the host), otherwise and while
// the texture is pending, slot 0 (the placeholder). A pending key is flagged in the feedback
// buffer for the host to resolve; every lane that reads an entry sees the same translation, so
// the unconditional store never races with a different value.
static uint32_t BindlessSlot(ValueEmitContext& ctx, const IR::ImageResource& image,
                             IR::Value image_arg) {
	auto&       state  = ctx.state;
	const auto* handle = image_arg.ResolveInstruction();
	EXIT_IF(handle == nullptr || handle->NumArgs() == 0u || state.flattened_srt_variable == 0 ||
	        state.bindless_translation_variable == 0);
	const auto key  = ctx.Def(handle->Arg(0));
	const auto Load = [&](uint32_t variable, uint32_t index) {
		const auto pointer = state.builder.AllocateId();
		state.builder.AddFunction(spv::OpAccessChain, TypeStorageBufferElementPointer(state),
		                          pointer, variable, ConstantU32(state, 0), index);
		const auto value = state.builder.AllocateId();
		state.builder.AddFunction(spv::OpLoad, TypeU32(state), value, pointer);
		return value;
	};
	const auto base     = Load(state.flattened_srt_variable,
	                           ConstantU32(state, image.indirect_mapping_offset));
	const auto count    = Load(state.flattened_srt_variable,
	                           ConstantU32(state, image.indirect_mapping_offset + 1u));
	const auto in_range = Binary(state, spv::OpULessThan, TypeBool(state), key, count);
	const auto entry    = Binary(state, spv::OpIAdd, TypeU32(state), base, key);
	const auto index    = state.builder.AllocateId();
	state.builder.AddFunction(spv::OpSelect, TypeU32(state), index, in_range, entry,
	                          ConstantU32(state, 0u));
	const auto raw     = Load(state.bindless_translation_variable, index);
	const auto pending = Binary(state, spv::OpIEqual, TypeBool(state), raw,
	                            ConstantU32(state, IR::BindlessPending));
	if (state.bindless_feedback_variable != 0) {
		const auto pending_flag = state.builder.AllocateId();
		state.builder.AddFunction(spv::OpSelect, TypeU32(state), pending_flag, pending,
		                          ConstantU32(state, 1u), ConstantU32(state, 0u));
		// Diagnostics: a key outside its heap leaves itself (with the top bit set) in
		// feedback word 0, which belongs to no heap.
		const auto marked_key = Binary(state, spv::OpBitwiseOr, TypeU32(state), key,
		                               ConstantU32(state, 0x80000000u));
		const auto flag = state.builder.AllocateId();
		state.builder.AddFunction(spv::OpSelect, TypeU32(state), flag, in_range, pending_flag,
		                          marked_key);
		const auto pointer = state.builder.AllocateId();
		state.builder.AddFunction(spv::OpAccessChain, TypeStorageBufferElementPointer(state),
		                          pointer, state.bindless_feedback_variable, ConstantU32(state, 0),
		                          index);
		state.builder.AddFunction(spv::OpStore, pointer, flag);
	}
	const auto slot    = state.builder.AllocateId();
	// Pending keys sample slot 2 (the blue placeholder) while their texture is loaded.
	state.builder.AddFunction(spv::OpSelect, TypeU32(state), slot, pending, ConstantU32(state, 2u),
	                          raw);
	state.builder.AddAnnotation(spv::OpDecorate, slot, spv::DecorationNonUniform);
	return slot;
}

static uint32_t GlslExt(EmitterState& state, uint32_t type, uint32_t opcode,
                        std::initializer_list<uint32_t> args) {
	const auto            result = state.builder.AllocateId();
	std::vector<uint32_t> words {spv::OpExtInst, type, result, GlslStd450(state), opcode};
	words.insert(words.end(), args.begin(), args.end());
	state.builder.AddFunction(words);
	return result;
}

// IMAGE_GATHER4_L on a 2D or 2D-array image. Core Vulkan gathers take no explicit LOD, so fetch
// the 2x2 footprint at the rounded level instead, with clamp-to-edge addressing, returning the
// components in gather order: (i0, j1), (i1, j1), (i1, j0), (i0, j0).
static uint32_t EmitGatherAtLod(ValueEmitContext& ctx, const IR::MemoryInfo& mem, uint32_t coord,
                                uint32_t lod, bool arrayed,
                                Prospero::TextureNumericClass numeric_class, uint32_t component) {
	auto& state = ctx.state;
	state.builder.RequireCapability(spv::CapabilityImageQuery);
	const auto image   = LoadSampledImageDescriptor(state, mem.resource);
	const auto i32     = TypeI32(state);
	const auto f32     = TypeF32(state);
	const auto half    = ConstantF32(state, 0x3f000000u);
	const auto Extract = [&](uint32_t type, uint32_t composite, uint32_t index) {
		const auto value = state.builder.AllocateId();
		state.builder.AddFunction(spv::OpCompositeExtract, type, value, composite, index);
		return value;
	};
	const auto Round = [&](uint32_t value) {
		return Unary(state, spv::OpConvertFToS, i32,
		             GlslExt(state, f32, GLSLstd450Floor,
		                     {Binary(state, spv::OpFAdd, f32, value, half)}));
	};
	const auto Clamp = [&](uint32_t value, uint32_t last) {
		return GlslExt(state, i32, GLSLstd450SClamp, {value, ConstantI32(state, 0), last});
	};
	const auto levels = state.builder.AllocateId();
	state.builder.AddFunction(spv::OpImageQueryLevels, i32, levels, image);
	const auto level =
	    Clamp(Round(lod), Binary(state, spv::OpISub, i32, levels, ConstantI32(state, 1)));
	const uint32_t size_components = arrayed ? 3u : 2u;
	const auto     size            = state.builder.AllocateId();
	state.builder.AddFunction(spv::OpImageQuerySizeLod, TypeI32Vector(state, size_components), size,
	                          image, level);
	// Texels i0 = floor(c * extent - 0.5) and i0 + 1 on one axis, clamped to the level.
	const auto Axis = [&](uint32_t axis) {
		const auto extent = Extract(i32, size, axis);
		const auto scaled = Binary(state, spv::OpFMul, f32, Extract(f32, coord, axis),
		                           Unary(state, spv::OpConvertSToF, f32, extent));
		const auto first  = Unary(state, spv::OpConvertFToS, i32,
		                          GlslExt(state, f32, GLSLstd450Floor,
		                                  {Binary(state, spv::OpFSub, f32, scaled, half)}));
		const auto last   = Binary(state, spv::OpISub, i32, extent, ConstantI32(state, 1));
		return std::pair {Clamp(first, last),
		                  Clamp(Binary(state, spv::OpIAdd, i32, first, ConstantI32(state, 1)), last)};
	};
	const auto [x0, x1] = Axis(0);
	const auto [y0, y1] = Axis(1);
	uint32_t   layer    = 0;
	if (arrayed) {
		layer = Clamp(Round(Extract(f32, coord, 2)),
		              Binary(state, spv::OpISub, i32, Extract(i32, size, 2), ConstantI32(state, 1)));
	}
	const auto vector_type = ImageVectorType(state, numeric_class, 4);
	const auto scalar_type = ImageScalarType(state, numeric_class);
	const auto Fetch       = [&](uint32_t x, uint32_t y) {
        const auto position = state.builder.AllocateId();
        if (arrayed) {
            state.builder.AddFunction(spv::OpCompositeConstruct, TypeI32Vector(state, 3), position,
			                                x, y, layer);
        } else {
            state.builder.AddFunction(spv::OpCompositeConstruct, TypeI32Vector(state, 2), position,
			                                x, y);
        }
        const auto texel = state.builder.AllocateId();
        state.builder.AddFunction(spv::OpImageFetch, vector_type, texel, image, position,
		                                spv::ImageOperandsLodMask, level);
        return Extract(scalar_type, texel, component);
	};
	const auto result = state.builder.AllocateId();
	state.builder.AddFunction(spv::OpCompositeConstruct, vector_type, result, Fetch(x0, y1),
	                          Fetch(x1, y1), Fetch(x1, y0), Fetch(x0, y0));
	return result;
}

// The bindless sampler array slot of the sampler handle's key: region + key while the key is
// inside the heap's entry count (both from the flattened SRT, patched by the host), otherwise
// slot 0, the default sampler.
static uint32_t BindlessSamplerSlot(ValueEmitContext& ctx, const IR::SamplerResource& sampler,
                                    IR::Value sampler_arg) {
	auto&       state  = ctx.state;
	const auto* handle = sampler_arg.ResolveInstruction();
	EXIT_IF(handle == nullptr || handle->NumArgs() == 0u || state.flattened_srt_variable == 0);
	const auto key  = ctx.Def(handle->Arg(0));
	const auto Load = [&](uint32_t index) {
		const auto pointer = state.builder.AllocateId();
		state.builder.AddFunction(spv::OpAccessChain, TypeStorageBufferElementPointer(state),
		                          pointer, state.flattened_srt_variable, ConstantU32(state, 0),
		                          ConstantU32(state, index));
		const auto value = state.builder.AllocateId();
		state.builder.AddFunction(spv::OpLoad, TypeU32(state), value, pointer);
		return value;
	};
	const auto base     = Load(sampler.bindless_mapping_offset);
	const auto count    = Load(sampler.bindless_mapping_offset + 1u);
	const auto in_range = Binary(state, spv::OpULessThan, TypeBool(state), key, count);
	const auto entry    = Binary(state, spv::OpIAdd, TypeU32(state), base, key);
	const auto slot     = state.builder.AllocateId();
	state.builder.AddFunction(spv::OpSelect, TypeU32(state), slot, in_range, entry,
	                          ConstantU32(state, 0u));
	state.builder.AddAnnotation(spv::OpDecorate, slot, spv::DecorationNonUniform);
	return slot;
}

void EmitImage(ValueEmitContext& ctx, const IR::Inst& inst) {
	const auto op         = inst.GetOpcode();
	const auto image_info = IR::ImageOpcodeInfoOf(op);
	auto&       state     = ctx.state;
	const auto& mem       = ctx.Memory(inst);
	const auto  image_arg = inst.Arg(0);
	ctx.ResourceIndex(image_arg, IR::ValueOpcode::GetImageResource);
	const auto& image   = state.program.info.images.at(mem.resource);
	state.bindless_slot = image.bindless ? BindlessSlot(ctx, image, image_arg) : 0u;
	state.bindless_sampler_slot = 0u;
	if (image_info.needs_sampler && inst.NumArgs() > 1u &&
	    mem.sampler < state.program.info.samplers.size() &&
	    state.program.info.samplers[mem.sampler].bindless) {
		state.bindless_sampler_slot =
		    BindlessSamplerSlot(ctx, state.program.info.samplers[mem.sampler], inst.Arg(1));
	}
	const auto* address = ctx.ImageAddress(inst.Arg(image_info.needs_sampler ? 2 : 1));
	if (op == IR::ValueOpcode::ImageQueryDimensions) {
		state.builder.RequireCapability(spv::CapabilityImageQuery);
		ctx.Define(inst, QueryDimensions(ctx, mem, *address));
		return;
	}
	if (op == IR::ValueOpcode::ImageQueryLod) {
		state.builder.RequireCapability(spv::CapabilityImageQuery);
		const auto dimension = image.dimension;
		const auto sampled   = MakeSampledImage(state, mem.resource, mem.sampler);
		const auto lod       = state.builder.AllocateId();
		state.builder.AddFunction(
		    spv::OpImageQueryLod, TypeF32Vector(state, 2), lod, sampled,
		    CoordF32(ctx, mem, *address, 0, ImageDimensionInfoFor(dimension).spatial_components,
		             image.cube));
		uint32_t values[4] = {ConstantU32(state, 0), ConstantU32(state, 0), ConstantU32(state, 0),
		                      ConstantU32(state, 0)};
		for (uint32_t index = 0; index < 2u; index++) {
			const auto component = state.builder.AllocateId();
			state.builder.AddFunction(spv::OpCompositeExtract, TypeF32(state), component, lod,
			                          index);
			values[index] = FloatBits(ctx, component);
		}
		const auto result = state.builder.AllocateId();
		state.builder.AddFunction(spv::OpCompositeConstruct, TypeU32Vector(state, 4), result,
		                          values[0], values[1], values[2], values[3]);
		ctx.Define(inst, result);
		return;
	}
	if (op == IR::ValueOpcode::ImageRead) {
		const auto  dimension      = image.dimension;
		const auto& dimension_info = ImageDimensionInfoFor(dimension);
		const auto  numeric_class  = image.numeric_class;
		const auto  condition      = ctx.Arg(inst, 2);
		ctx.Define(
		    inst,
		    EmitValueOrDefaultIfCondition(
		        state, condition, TypeU32Vector(state, 4), ConstantU32CompositeZero(state, 4),
		        [&]() {
			        const auto descriptor = LoadSampledImageDescriptor(state, mem.resource);
			        const auto color      = state.builder.AllocateId();
			        const auto coord      = CoordU32(ctx, mem, *address, dimension);
			        if (dimension_info.multisampled != 0u) {
				        state.builder.AddFunction(
				            spv::OpImageFetch, ImageVectorType(state, numeric_class, 4), color,
				            descriptor, coord, spv::ImageOperandsSampleMask,
				            AddressU32(ctx, mem, *address, dimension_info.coordinate_components));
			        } else {
				        state.builder.AddFunction(spv::OpImageFetch,
				                                  ImageVectorType(state, numeric_class, 4), color,
				                                  descriptor, coord, spv::ImageOperandsLodMask,
				                                  LodU32(ctx, mem, *address, dimension));
			        }
			        return ResultVector(ctx, UnpackImageTexel(ctx, mem, color), numeric_class,
			                            false, mem);
		        }));
		return;
	}
	if (op == IR::ValueOpcode::ImageWrite) {
		const bool uint_image = image.numeric_class == Prospero::TextureNumericClass::Uint;
		const auto dimension  = image.dimension;
		EmitIfCondition(state, ctx.Arg(inst, 3), [&]() {
			const auto mip_lod =
			    state.program.info.images[mem.resource].mip_mode == IR::ImageMipMode::DynamicStorage
			        ? LodU32(ctx, mem, *address, dimension)
			        : 0u;
			const auto coord = CoordU32(ctx, mem, *address, dimension);
			const auto texel = StoreTexel(ctx, mem, ctx.Arg(inst, 2), uint_image);
			EmitStorageImageWrite(state, mem.resource, mip_lod, coord, texel);
		});
		return;
	}
	if (op == IR::ValueOpcode::ImageSampleRaw || op == IR::ValueOpcode::ImageGatherRaw) {
		const auto  dimension      = image.dimension;
		const auto& dimension_info = ImageDimensionInfoFor(dimension);
		const auto  layout         = Layout(mem);
		const auto  numeric_class  = image.numeric_class;
		const bool  dref           = HasFlag(mem, Decoder::ImageSampleFlagCompare);
		if (dref && state.program.info.images[mem.resource].conversion_format !=
		                Prospero::BufferFormat::kInvalid) {
			ctx.Fail(inst, "uses depth comparison with a packed integer image");
			return;
		}
		if (op == IR::ValueOpcode::ImageGatherRaw) {
			const auto coord = CoordF32(ctx, mem, *address, layout.coord,
			                            dimension_info.coordinate_components, image.cube);
			if (HasFlag(mem, Decoder::ImageSampleFlagLod) && !dref &&
			    layout.lod != NoImageComponent && !image.cube &&
			    (dimension == ImageDimension::Dim2D || dimension == ImageDimension::Dim2DArray) &&
			    layout.offset == NoImageComponent &&
			    !HasFlag(mem, Decoder::ImageSampleFlagGatherHorizontal) &&
			    ImageConversionFormat(state, mem).format == Prospero::BufferFormat::kInvalid) {
				const auto gathered =
				    EmitGatherAtLod(ctx, mem, coord, AddressF32(ctx, mem, *address, layout.lod),
				                    dimension == ImageDimension::Dim2DArray, numeric_class,
				                    ImageGatherComponent(mem.dmask));
				ctx.Define(inst, ResultVector(ctx, UnpackImageGather(ctx, mem, gathered),
				                              numeric_class, false, mem, true));
				return;
			}
			if (HasFlag(mem, Decoder::ImageSampleFlagLod)) {
				static std::atomic_flag warned = ATOMIC_FLAG_INIT;
				if (!warned.test_and_set(std::memory_order_relaxed)) {
					std::fputs("Warning: approximating IMAGE_GATHER4_L at mip level 0; explicit LOD is ignored.\n",
					           stderr);
				}
			}
			if (dimension == ImageDimension::Dim1D) {
				if (dref || !HasFlag(mem, Decoder::ImageSampleFlagLevelZero) ||
				    HasFlag(mem, Decoder::ImageSampleFlagOffset) ||
				    HasFlag(mem, Decoder::ImageSampleFlagGatherHorizontal)) {
					ctx.Fail(inst, "has an unsupported 1D gather variant");
					return;
				}
				const auto sample = EmitOneDimensionalGatherLz(ctx, mem, coord, numeric_class);
				ctx.Define(inst, ResultVector(ctx, UnpackImageGather(ctx, mem, sample),
				                              numeric_class, false, mem, true));
				return;
			}
			if (dimension == ImageDimension::Dim1DArray) {
				ctx.Fail(inst, "has an unsupported 1D-array gather");
				return;
			}
			const auto            sampled = MakeSampledImage(state, mem.resource, mem.sampler);
			const auto            sample  = state.builder.AllocateId();
			std::vector<uint32_t> words;
			if (dref) {
				auto dref_value = ZeroF32(state);
				if (layout.dref != NoImageComponent) {
					dref_value = AddressF32(ctx, mem, *address, layout.dref);
				}
				words = {spv::OpImageDrefGather,
				         TypeF32Vector(state, 4),
				         sample,
				         sampled,
				         coord,
				         dref_value};
			} else {
				uint32_t component = 0;
				if (ImageConversionFormat(state, mem).format == Prospero::BufferFormat::kInvalid) {
					component = ImageGatherComponent(mem.dmask);
				}
				words = {spv::OpImageGather,
				         ImageVectorType(state, numeric_class, 4),
				         sample,
				         sampled,
				         coord,
				         ConstantU32(state, component)};
			}
			if (HasFlag(mem, Decoder::ImageSampleFlagGatherHorizontal)) {
				words.push_back(spv::ImageOperandsConstOffsetsMask);
				words.push_back(HorizontalOffsets(state, dimension));
			} else if (layout.offset != NoImageComponent) {
				words.push_back(spv::ImageOperandsOffsetMask);
				words.push_back(PackedOffset(ctx, mem, *address, layout, dimension));
			}
			state.builder.AddFunction(words);
			auto result_numeric_class = numeric_class;
			if (dref) {
				result_numeric_class = Prospero::TextureNumericClass::Float;
			}
			ctx.Define(inst, ResultVector(ctx, UnpackImageGather(ctx, mem, sample),
			                              result_numeric_class, false, mem, true));
			return;
		}
		const bool explicit_lod = HasFlag(mem, Decoder::ImageSampleFlagDerivative) ||
		                          HasFlag(mem, Decoder::ImageSampleFlagLod) ||
		                          HasFlag(mem, Decoder::ImageSampleFlagLevelZero) ||
		                          state.program.stage != ShaderType::Pixel;
		auto       opcode       = spv::OpImageSampleImplicitLod;
		if (explicit_lod) {
			opcode = dref ? spv::OpImageSampleDrefExplicitLod : spv::OpImageSampleExplicitLod;
		} else if (dref) {
			opcode = spv::OpImageSampleDrefImplicitLod;
		}
		uint32_t result_type = ImageVectorType(state, numeric_class, 4);
		uint32_t dref_value  = 0;
		if (dref) {
			result_type = TypeF32(state);
			dref_value  = ZeroF32(state);
			if (layout.dref != NoImageComponent) {
				dref_value = AddressF32(ctx, mem, *address, layout.dref);
			}
		}
		// IMAGE_SAMPLE*_CL: the last address component is a minimum LOD. Implicit and gradient
		// samples take it as the MinLod operand; explicit-LOD forms (every sample outside pixel
		// shaders) raise their LOD to it.
		uint32_t lod_clamp = 0;
		if (layout.clamp != NoImageComponent && mem.image_address_components > layout.clamp) {
			lod_clamp = AddressF32(ctx, mem, *address, layout.clamp);
		}
		const bool gradient   = HasFlag(mem, Decoder::ImageSampleFlagDerivative);
		const bool min_lod_op = lod_clamp != 0u && (gradient || !explicit_lod) &&
		                        GetHostImageFeatures().min_lod;
		uint32_t              explicit_lod_value = 0;
		uint32_t              operand_mask       = 0;
		std::vector<uint32_t> operands;
		if (gradient) {
			operand_mask |= spv::ImageOperandsGradMask;
			operands.push_back(
			    CoordF32(ctx, mem, *address, layout.grad_x, dimension_info.spatial_components));
			operands.push_back(
			    CoordF32(ctx, mem, *address, layout.grad_y, dimension_info.spatial_components));
		} else if (explicit_lod) {
			operand_mask |= spv::ImageOperandsLodMask;
			auto lod = ZeroF32(state);
			if (HasFlag(mem, Decoder::ImageSampleFlagLod) && layout.lod != NoImageComponent) {
				lod = AddressF32(ctx, mem, *address, layout.lod);
			}
			if (lod_clamp != 0u) {
				const auto clamped = state.builder.AllocateId();
				state.builder.AddFunction(spv::OpExtInst, TypeF32(state), clamped, GlslStd450(state),
				                          GLSLstd450FMax, lod, lod_clamp);
				lod = clamped;
			}
			explicit_lod_value = lod;
			operands.push_back(lod);
		} else if (layout.bias != NoImageComponent) {
			operand_mask |= spv::ImageOperandsBiasMask;
			operands.push_back(AddressF32(ctx, mem, *address, layout.bias));
		}
		const auto sample_offset = SampleOffsetFor(ctx, inst, mem, *address, layout, dimension,
		                                           image.cube, image.bindless);
		if (sample_offset.const_offset != 0u) {
			operand_mask |= spv::ImageOperandsConstOffsetMask;
			operands.push_back(sample_offset.const_offset);
		}
		if (min_lod_op) {
			state.builder.RequireCapability(spv::CapabilityMinLod);
			operand_mask |= spv::ImageOperandsMinLodMask;
			operands.push_back(lod_clamp);
		} else if (lod_clamp != 0u && !explicit_lod) {
			static std::atomic_flag warned = ATOMIC_FLAG_INIT;
			if (!warned.test_and_set(std::memory_order_relaxed)) {
				std::fputs("Warning: IMAGE_SAMPLE*_CL clamp ignored: the device lacks "
				           "shaderResourceMinLod.\n",
				           stderr);
			}
		}
		const auto EmitSample = [&](uint32_t resource) {
			const auto& candidate = state.program.info.images[resource];
			auto        coord =
			    CoordF32(ctx, mem, *address, layout.coord,
			             ImageDimensionInfoFor(candidate.dimension).coordinate_components,
			             candidate.cube);
			if (sample_offset.dynamic) {
				uint32_t level = ZeroF32(state);
				if (explicit_lod_value != 0u) {
					level = explicit_lod_value;
				} else if (!HasFlag(mem, Decoder::ImageSampleFlagLevelZero) &&
				           state.program.stage == ShaderType::Pixel) {
					// The level an implicit or gradient sample reads, relative to the view base.
					state.builder.RequireCapability(spv::CapabilityImageQuery);
					const auto query = state.builder.AllocateId();
					state.builder.AddFunction(
					    spv::OpImageQueryLod, TypeF32Vector(state, 2), query,
					    MakeSampledImage(state, resource, mem.sampler),
					    CoordF32(ctx, mem, *address, layout.coord,
					             ImageDimensionInfoFor(candidate.dimension).spatial_components,
					             candidate.cube));
					level = state.builder.AllocateId();
					state.builder.AddFunction(spv::OpCompositeExtract, TypeF32(state), level, query,
					                          0u);
				}
				coord = ApplyDynamicSampleOffset(state, resource, coord, candidate.dimension,
				                                 sample_offset.packed, level);
			}
			const auto            sampled = MakeSampledImage(state, resource, mem.sampler);
			const auto            sample  = state.builder.AllocateId();
			std::vector<uint32_t> sample_operands {result_type, sample, sampled, coord};
			if (dref) {
				sample_operands.push_back(dref_value);
			}
			if (operand_mask != 0u) {
				sample_operands.push_back(operand_mask);
				sample_operands.insert(sample_operands.end(), operands.begin(), operands.end());
			}
			state.builder.AddFunction(opcode, sample_operands);
			return sample;
		};
		if (image.indirect_root != mem.resource || image.bindless) {
			const auto sample = EmitSample(mem.resource);
			auto       result = sample;
			if (!dref) {
				result = UnpackImageTexel(ctx, mem, sample);
			}
			ctx.Define(inst, ResultVector(ctx, result, numeric_class, dref, mem));
			return;
		}
		const auto* handle = image_arg.ResolveInstruction();
		const auto* source = image.source < state.program.descriptor_sources.size()
		                         ? &state.program.descriptor_sources[image.source]
		                         : nullptr;
		if (handle == nullptr || source == nullptr || !source->indirect_image.has_value() ||
		    handle->NumArgs() == 0u) {
			ctx.Fail(inst, "has invalid indirect image key provenance");
			return;
		}
		const auto key = ctx.Def(handle->Arg(0));
		if (state.flattened_srt_variable == 0 || image.indirect_search_iterations == 0u ||
		    image.indirect_resources.size() < 2u) {
			ctx.Fail(inst, "has no indirect image runtime mapping");
			return;
		}
		const auto LoadMapping = [&](uint32_t index) {
			const auto pointer = state.builder.AllocateId();
			state.builder.AddFunction(spv::OpAccessChain, TypeStorageBufferElementPointer(state),
			                          pointer, state.flattened_srt_variable, ConstantU32(state, 0),
			                          index);
			const auto value = state.builder.AllocateId();
			state.builder.AddFunction(spv::OpLoad, TypeU32(state), value, pointer);
			return value;
		};
		const auto mapping  = ConstantU32(state, image.indirect_mapping_offset);
		auto       low      = ConstantU32(state, 0u);
		auto       high     = LoadMapping(mapping);
		auto       selected = ConstantU32(state, 0u);
		for (uint32_t iteration = 0; iteration < image.indirect_search_iterations;
		     iteration++) {
			const auto active = Binary(state, spv::OpULessThan, TypeBool(state), low, high);
			const auto mid    = Binary(state, spv::OpShiftRightLogical, TypeU32(state),
			                           Binary(state, spv::OpIAdd, TypeU32(state), low, high),
			                           ConstantU32(state, 1u));
			const auto probe  = state.builder.AllocateId();
			state.builder.AddFunction(spv::OpSelect, TypeU32(state), probe, active, mid,
			                          ConstantU32(state, 0u));
			const auto entry = Binary(state, spv::OpIAdd, TypeU32(state), mapping,
			                          Binary(state, spv::OpIAdd, TypeU32(state),
			                                 Binary(state, spv::OpShiftLeftLogical, TypeU32(state),
			                                        probe, ConstantU32(state, 1u)),
			                                 ConstantU32(state, 1u)));
			const auto mapped_key = LoadMapping(entry);
			const auto candidate  = LoadMapping(
			    Binary(state, spv::OpIAdd, TypeU32(state), entry, ConstantU32(state, 1u)));
			const auto equal = Binary(state, spv::OpIEqual, TypeBool(state), mapped_key, key);
			const auto match = Binary(state, spv::OpLogicalAnd, TypeBool(state), active, equal);
			const auto next_selected = state.builder.AllocateId();
			state.builder.AddFunction(spv::OpSelect, TypeU32(state), next_selected, match,
			                          candidate, selected);
			selected              = next_selected;
			const auto less = Binary(state, spv::OpULessThan, TypeBool(state), mapped_key, key);
			const auto take_upper = Binary(state, spv::OpLogicalAnd, TypeBool(state), active, less);
			const auto take_lower = Binary(state, spv::OpLogicalAnd, TypeBool(state), active,
			                               Unary(state, spv::OpLogicalNot, TypeBool(state), less));
			const auto next_low   = state.builder.AllocateId();
			state.builder.AddFunction(
			    spv::OpSelect, TypeU32(state), next_low, take_upper,
			    Binary(state, spv::OpIAdd, TypeU32(state), mid, ConstantU32(state, 1u)), low);
			low                  = next_low;
			const auto next_high = state.builder.AllocateId();
			state.builder.AddFunction(spv::OpSelect, TypeU32(state), next_high, take_lower, mid,
			                          high);
			high = next_high;
		}
		const auto            default_label = state.builder.AllocateId();
		const auto            merge_label   = state.builder.AllocateId();
		std::vector<uint32_t> labels(image.indirect_resources.size() - 1u);
		std::vector<uint32_t> switch_words {spv::OpSwitch, selected, default_label};
		for (uint32_t candidate = 1; candidate < image.indirect_resources.size(); candidate++) {
			labels[candidate - 1u] = state.builder.AllocateId();
			switch_words.push_back(candidate);
			switch_words.push_back(labels[candidate - 1u]);
		}
		state.builder.AddFunction(spv::OpSelectionMerge, merge_label,
		                          spv::SelectionControlMaskNone);
		state.builder.AddFunction(switch_words);
		std::vector<uint32_t> phi_words {spv::OpPhi, result_type, state.builder.AllocateId()};
		EmitLabel(state, default_label);
		phi_words.push_back(EmitSample(image.indirect_resources[0]));
		phi_words.push_back(default_label);
		state.builder.AddFunction(spv::OpBranch, merge_label);
		for (uint32_t candidate = 1; candidate < image.indirect_resources.size(); candidate++) {
			EmitLabel(state, labels[candidate - 1u]);
			phi_words.push_back(EmitSample(image.indirect_resources[candidate]));
			phi_words.push_back(labels[candidate - 1u]);
			state.builder.AddFunction(spv::OpBranch, merge_label);
		}
		EmitLabel(state, merge_label);
		state.builder.AddFunction(phi_words);
		auto result = phi_words[2];
		if (!dref) {
			result = UnpackImageTexel(ctx, mem, result);
		}
		ctx.Define(inst, ResultVector(ctx, result, numeric_class, dref, mem));
		return;
	}
	if (image_info.access == IR::ImageAccess::Atomic) {
		const auto dimension = image.dimension;
		ctx.Define(inst, EmitValueOrZeroIfCondition(state, ctx.Arg(inst, inst.NumArgs() - 1), [&]() {
			           const auto pointer      = state.builder.AllocateId();
			           const auto pointer_type = state.builder.Type(
			               spv::OpTypePointer, spv::StorageClassImage, TypeU32(state));
			           state.builder.AddFunction(spv::OpImageTexelPointer, pointer_type, pointer,
			                                     StorageImageDescriptorPointer(state, mem.resource),
			                                     CoordU32(ctx, mem, *address, dimension),
			                                     ConstantU32(state, 0));
			           if (op == IR::ValueOpcode::ImageAtomicFMin32 ||
			               op == IR::ValueOpcode::ImageAtomicFMax32) {
				           return AtomicUpdate(state, pointer, IR::ResourceKind::Image,
				                               [&](uint32_t old) {
					                               return EmitFloatAtomicReplacement(
					                                   state, old, ctx.Arg(inst, 2),
					                                   op == IR::ValueOpcode::ImageAtomicFMax32);
				                               });
			           }
			           const auto old = EmitAtomicOperation(ctx, inst, pointer, spv::ScopeDevice);
			           EmitAtomicMemoryBarrier(state, IR::ResourceKind::Image);
			           return old;
		           }));
		return;
	}
	ctx.Fail(inst, "has no image SPIR-V emitter");
}

} // namespace Libs::Graphics::ShaderRecompiler::Spirv::Emitter
